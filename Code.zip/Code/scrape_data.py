import DataLoader as DL
import os.path as path

season = 2020

DataLoaderObj = DL.DataLoader()
DataLoaderObj.process_data(2020)
